<?php
namespace NS1\SubNS;

class SubNameSpaced {
}

interface SubNameSpacedInterface {
}
