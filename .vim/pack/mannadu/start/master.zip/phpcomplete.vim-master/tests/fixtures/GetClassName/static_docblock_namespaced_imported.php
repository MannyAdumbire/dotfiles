<?php
use Foo\Page;

$p = Page::getPage();
$p->
