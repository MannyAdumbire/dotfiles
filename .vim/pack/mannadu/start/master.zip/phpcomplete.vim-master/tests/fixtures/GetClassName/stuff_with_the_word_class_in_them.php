<?php

class Foo extends DateTime {

	public function bar() {
		$var = 'Anything with a
			class will loop to the infinite';
		$this-> // call completion here

		$verylongvariablethatcausesnextlinetowrap =
		classname();
		self:: // call completion here

		classify_is_a_nice_method_name_isnt_it();
		parent:: // call completion here
	}
}
